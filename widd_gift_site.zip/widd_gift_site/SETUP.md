# وِدّ — دليل تشغيل الروابط القصيرة

## ما الذي يقدمه الموقع؟
- صفحة إنشاء هدية وصفحة استقبال منفصلتان.
- ثلاث خانات رسائل تفتح باللمس.
- صورتان ومقطع موسيقي ورسالة ختامية.
- أربعة قوالب بألوان ليلية بنفسجية وزرقاء.
- يعمل على الهاتف والكمبيوتر.
- يدعم الروابط القصيرة عبر Supabase المجاني بعد ربط قاعدة البيانات.

## 1) إعداد قاعدة البيانات المجانية
1. أنشئ مشروعًا مجانيًا في https://supabase.com/
2. افتح SQL Editor ثم New query.
3. الصق وشغّل هذا الأمر:

```sql
create table if not exists public.gifts (
  id text primary key,
  payload jsonb not null,
  created_at timestamptz not null default now()
);

alter table public.gifts enable row level security;

create policy "Anyone can create a gift"
on public.gifts for insert
to anon
with check (true);

create or replace function public.get_gift(gift_id text)
returns jsonb
language sql
security definer
set search_path = public
as $$
  select payload from public.gifts where id = gift_id limit 1;
$$;

revoke all on function public.get_gift(text) from public;
grant execute on function public.get_gift(text) to anon;
grant insert on public.gifts to anon;
```

هذه الطريقة تسمح بفتح هدية بمعرفة رمزها، ولا تمنح الزوار صلاحية قراءة جدول الهدايا كاملًا مباشرةً. مع ذلك، أي شخص يملك رابط هدية يستطيع مشاهدة محتواها؛ لا تضع كلمات مرور أو معلومات شخصية حساسة فيها.

## 2) ربط الموقع
من Supabase افتح Project Settings → API (أو Data API حسب الواجهة) وخذ:
- Project URL
- anon / publishable key (لا تستخدم service_role أبدًا)

افتح `index.html` وابحث عن السطرين:

```js
const SUPABASE_URL = "";
const SUPABASE_ANON_KEY = "";
```

ضع رابط المشروع والمفتاح العام بين علامتي الاقتباس. مثال شكلي فقط:

```js
const SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
const SUPABASE_ANON_KEY = "YOUR_PUBLIC_ANON_KEY";
```

لا تضع مفتاح `service_role` في موقع الويب.

## 3) نشر الموقع مجانًا
ارفع ملف `index.html` بعد ربط Supabase إلى Netlify Drop:
https://app.netlify.com/drop

بعد النشر ستحصل على رابط الموقع الأساسي. افتحه وجرب إنشاء هدية؛ الرابط الناتج سيكون قصيرًا مثل:
`https://your-site.netlify.app/?g=رمز-قصير`

يمكنك تغيير اسم الموقع الفرعي من إعدادات Netlify إلى اسم متاح.

## ملاحظات
- النسخة بدون إعداد Supabase تعمل بوضع رابط طويل مؤقت داخل الجزء `#gift=`.
- بعد إضافة بيانات Supabase وإعادة النشر، تُحفظ الهدايا في قاعدة البيانات وتُنشأ روابط قصيرة.
- الصور يتم تصغيرها في المتصفح، والملف الصوتي محدود بـ700KB لتجنب هدايا ضخمة.
- لا تشارك مفاتيح خاصة، ولا تستخدم مفتاح service_role في المتصفح.
